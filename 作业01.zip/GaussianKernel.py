import math
import numpy as np
# def gauss_function:


def  gaussKernel(sig,m=None):
    kernel_size=math.ceil(3*sig)*2+1
    if m==None:
        m=kernel_size
    elif m<kernel_size:
        print("Warning! m is too small!")
    k=np.zeros([m,m])
    print("kernel size :",m)
    c=m//2
    factor=1 / (2 * math.pi * sig * sig)

    for i in range(m):
        for j in range(m):
            k[i][j]=factor*np.exp(-(pow(i-c,2)+pow(j-c,2))/(2*pow(sig,2)))
    k = k / np.sum(k)
    # print(k)
    return k
if __name__=='__main__':
    #指定滤波器大小
    print(gaussKernel(0.5,3))
    #不指定
    print(gaussKernel(0.5))



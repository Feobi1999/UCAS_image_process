
import cv2
import numpy as np
import matplotlib.pyplot as plt
from rgb1gary import rgb1gray
from twodconv import twodConv
from GaussianKernel import gaussKernel


def process_img(img):
    sigma=[1,2,3,5]
    output_res=[]
    for sig in sigma:
        k=gaussKernel(sig)
        output=twodConv(img,k,'replicate')
        output_res.append(output)

    plt.subplot(221)
    plt.title("sig=1")
    plt.tight_layout()
    plt.imshow(output_res[0],cmap='gray')
    plt.subplot(222)
    plt.title("sig=2")
    plt.tight_layout()
    plt.imshow(output_res[1],cmap='gray')
    plt.subplot(223)
    plt.title("sig=3")
    plt.tight_layout()
    plt.imshow(output_res[2],cmap='gray')
    plt.subplot(224)
    plt.title("sig=5")
    plt.tight_layout()
    plt.imshow(output_res[3],cmap='gray')
    plt.show()


if __name__=='__main__':
    #不同sigma对4副图滤波
    img1 = cv2.imread('einstein.tif', cv2.IMREAD_GRAYSCALE)
    process_img(img1)
    img2=cv2.imread('cameraman.tif', cv2.IMREAD_GRAYSCALE)
    process_img(img2)
    img3=cv2.imread("lena512color.tiff")
    g3 = rgb1gray(img3, 'NTSC')
    process_img(g3)
    img4=cv2.imread("mandril_color.tif")
    g4 = rgb1gray(img4, 'NTSC')
    process_img(g4)

#直接调用cv2和自己写的函数的对比
    sigma=1
    k = gaussKernel(sigma)
    img11 = cv2.imread('mandril_color.tif',cv2.IMREAD_GRAYSCALE)
    img_Guassian = cv2.GaussianBlur(img11,(7,7),sigmaX=sigma,sigmaY=sigma)
    output = twodConv(img11, k, 'replicate')


    plt.subplot(121)
    plt.title("ours")
    plt.tight_layout()
    plt.imshow(output, cmap='gray')
    plt.subplot(122)
    plt.title("opencv gaussian")
    plt.tight_layout()
    plt.imshow(img_Guassian, cmap='gray')
    plt.show()
    img_dif1=abs(output-img_Guassian)
    plt.title("diff(cv2,ours)")
    # print(img_dif)
    plt.imshow(img_dif1,cmap='gray')
    plt.show()

    # 不同padding方式对比
    output2 = twodConv(img11, k)
    plt.subplot(121)
    plt.title("zeros")
    plt.tight_layout()
    plt.imshow(output2, cmap='gray')
    plt.subplot(122)
    plt.title("replicate")
    plt.tight_layout()
    plt.imshow(output, cmap='gray')
    plt.show()

    img_dif2=abs(output-output2)
    print(img_dif2)
    plt.title("diff_of_padding")
    plt.imshow(img_dif2,cmap='gray')
    plt.show()

   #处理另一幅图
    img22 = cv2.imread('lena512color.tiff', cv2.IMREAD_GRAYSCALE)
    img_Guassian = cv2.GaussianBlur(img22, (7, 7), sigmaX=sigma, sigmaY=sigma)
    output = twodConv(img22, k, 'replicate')
    output2 = twodConv(img22, k)

    plt.subplot(121)
    plt.title("ours")
    plt.tight_layout()
    plt.imshow(output, cmap='gray')
    plt.subplot(122)
    plt.title("opencv gaussian")
    plt.tight_layout()
    plt.imshow(img_Guassian, cmap='gray')
    plt.show()
    img_dif1 = abs(output - img_Guassian)
    plt.title("diff(cv2,ours)")
    # print(img_dif)
    plt.imshow(img_dif1, cmap='gray')
    plt.show()

    plt.subplot(121)
    plt.title("zeros")
    plt.tight_layout()
    plt.imshow(output2, cmap='gray')
    plt.subplot(122)
    plt.title("replicate")
    plt.tight_layout()
    plt.imshow(output, cmap='gray')
    plt.show()

    img_dif2 = abs(output - output2)
    print(img_dif2)
    plt.title("diff_of_padding")
    plt.imshow(img_dif2, cmap='gray')
    plt.show()










import cv2
import matplotlib.pyplot as plt


def rgb1gray(f,method):
    f=f[:,:,(2,1,0)]    #bgr-----rgb
    r,g,b=[(f[:,:,x]).astype(int) for x in range(3)]

    if method=='average':
        gray=(r+g+b)/3.0
    elif method=='NTSC':
        gray = r * 0.2989 + g * 0.5870 + b * 0.1140
        # print(gray.shape)
    return gray


def vis(f):
    g1 = rgb1gray(f, 'average')
    g2 = rgb1gray(f, 'NTSC')
    cv2.imwrite('mandril_color.jpg',g2)
    plt.subplot(211)
    plt.title("average")
    plt.tight_layout()
    plt.imshow(g1, cmap="gray")
    plt.subplot(212)
    plt.imshow(g2, cmap="gray")
    plt.title('NTSC')
    plt.tight_layout()
    plt.show()

if __name__=='__main__':

    f1=cv2.imread('lena512color.tiff')
    vis(f1)

    f2=f=cv2.imread('mandril_color.tif')
    vis(f2)


import cv2
import matplotlib.pyplot as plt
import numpy as np

def  scanLine4e(f,I,loc):
    if loc=="row":
        temp=f[I,:]
        print(np.shape(temp))
    elif loc=="column":
        temp=f[:,I]
    return temp




img1=cv2.imread("cameraman.tif")
row = np.size(img1,0)
cols = np.size(img1,1)
s1=scanLine4e(img1,row//2,"row")
plt.imshow(s1,'gray')

# xr = np.linspace(1, row, row)
# xc = np.linspace(1, cols, cols)

# plt.figure()
# plt.plot(xc, s1, 'bo--', ms=2, label='row pixel')
# plt.ylabel('pixel value')
plt.title("row")
plt.show()
# plt.imsave("column.png",s1)

img2 = cv2.imread('einstein.tif')
row = np.size(img2,0)
cols = np.size(img2,1)
# xr = np.linspace(1, row, row)
# xc = np.linspace(1, cols, cols)
center_column = int(cols//2)
s2=scanLine4e(img2, center_column, 'column')
# plt.figure()
# plt.plot(xr, s2, 'bo--', ms=2, label='column pixel')
# plt.ylabel('pixel value')
plt.imshow(s2,'gray')
plt.title("column")
plt.show()
plt.imsave("column.png",s2)




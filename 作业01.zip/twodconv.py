
import numpy as np
from scipy import signal
import cv2
import matplotlib.pyplot as plt
def twodConv(f,w,method='zero'):
    f = f.astype(np.float)
    kernel_h,kernel_w=w.shape
    image_h,image_w=f.shape
    #zero padding
    result_image=np.zeros([image_h,image_w])
    pad_image = np.zeros([image_h + kernel_h - 1, image_w + kernel_w - 1])
    f_w=kernel_w//2
    f_h=kernel_h//2
    pad_image[f_h:image_h + f_h, f_w:image_w + f_w] = f

    if method=='replicate':
        #left and right
        pad_image[0:f_h,f_w:f_w+image_w]=f[0,:]
        pad_image[image_h+f_h:,f_w:f_w+image_w]=f[image_h-1,:]
        #bottom and top
        pad_image[f_h:f_h+image_h,0:f_w]=f[:,0].reshape([image_h,1])
        pad_image[f_h:f_h+image_h,image_w+f_w:]=f[:,image_w-1].reshape([image_h,1])

        #corner
        pad_image[0:f_h,0:f_w]=f[0][0]
        pad_image[image_h+f_h:,0:f_w]=f[image_h-1,0]
        pad_image[0:f_h,image_w+f_w:]=f[0,image_w-1]
        pad_image[image_h+f_h:,image_w+f_w:]=f[image_h-1,image_w-1]
    kernel_rot=np.rot90(w,2)
    for i in range(image_h):
        for j in range(image_w):
            ROI=pad_image[i:i+kernel_h,j:j+kernel_w]
            result_image[i][j] = np.sum(np.multiply(kernel_rot, ROI))
    result_image=result_image.clip(0,255)
    result_image=np.rint(result_image).astype('uint8')
    return result_image

if __name__=='__main__':

    img1 = cv2.imread('lena512color.tiff', cv2.IMREAD_GRAYSCALE)
    #sobel算子
    kernel=np.array([[-1,0,1],[-2,0,2],[-1,0,1]])
    res=twodConv(img1,kernel,method='replicate')
    plt.subplot(121)
    plt.title("ours_conv")
    plt.tight_layout()
    plt.imshow(res,cmap='gray')
    plt.subplot(122)
    plt.title("cv2s_conv")
    plt.tight_layout()
    #直接调用cv库
    res2=cv2.filter2D(img1,-1,kernel)
    plt.imshow(res2,cmap='gray')
    plt.show()



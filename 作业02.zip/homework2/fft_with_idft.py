import numpy as np
import matplotlib.pyplot as plt
from numpy.fft import *
from matplotlib.pylab import mpl
import cv2

def dft2D(f):
    F=np.fft.fft(f,axis=0)
    F=np.fft.fft(F,axis=1)
    return F

def idft2D(F):
    m,n=F.shape 
    return dft2D(F.conjugate())/(m*n).conjugate()
    



if __name__ == "__main__":
    image=cv2.imread('rose512.tif',-1)

    #normalize
    f=image/255.0
    
    
    F = dft2D(f)
    image_idft=idft2D(F)
    g = np.abs(image_idft)

    #difference
    d=abs(g-f)

    plt.subplot(131)
    plt.imshow(f,cmap='gray')
    plt.title('original image')
    plt.tight_layout()

    plt.subplot(132)
    plt.imshow(g,cmap='gray')
    plt.title('idft_image')
    plt.tight_layout()

    plt.subplot(133)
    plt.imshow(d, cmap='gray')
    plt.title('diff')
    plt.show()


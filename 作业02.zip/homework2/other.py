import numpy as np
# from scipy.fftpack import fft,ifft
import matplotlib.pyplot as plt
from numpy.fft import *
from matplotlib.pylab import mpl
import cv2
from fft_with_idft import dft2D,idft2D
import math


if __name__ == "__main__":

    files=['house','house02','lena_gray_512','lunar_surface','Characters_test_pattern']

    for filename in files:
        image=cv2.imread(filename+'.tif',-1)
        m,n=image.shape
        a=math.log2(m)
        b=math.log2(n)
        print(a,b)
        h=2**(int(a)+1)
        w=2**(int(b)+1)

        if a%1!=0:
            rectangle=np.zeros([h,w],dtype=np.uint8) 
            mid_x=int(h/2)
            mid_y=int(w/2)
            rectangle[mid_x-int(m/2):mid_x+int(m/2),mid_y-int(n/2):mid_y+int(n/2)]=image
        else:
            rectangle=image
        F=dft2D(rectangle)

        row, column = F.shape
        f_center1 = F[row // 2:, :][:, column // 2:]
        f_center2 = F[row // 2:, :][:, :column // 2]
        f_center3 = F[:row // 2, :][:, column // 2:]
        f_center4 = F[:row // 2, :][:, :column // 2]
        f_center = np.vstack((np.hstack((f_center1, f_center2)), np.hstack((f_center3, f_center4))))
        S = np.log(1 + np.abs(f_center))
        spec=np.abs(F)
        
        plt.subplot(221)
        plt.imshow(rectangle,cmap='gray')
        plt.title('original image')
        plt.tight_layout()

        plt.subplot(222)
        plt.title('Spectral image')
        plt.tight_layout()
        plt.imshow(np.abs(spec),cmap='gray')
        plt.subplot(223)
        plt.title('center Spectral')
        plt.tight_layout()   
        plt.imshow(np.abs(f_center),cmap='gray')
        plt.subplot(224)
        plt.tight_layout()
        plt.title('log center Spectral')
        plt.imshow(S,cmap='gray')
        plt.savefig('figure_'+filename+'.png')
        rectangle=np.array([])
        plt.show()
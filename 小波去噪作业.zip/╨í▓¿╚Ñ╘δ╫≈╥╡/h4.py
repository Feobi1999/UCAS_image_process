import os
import cv2
from matplotlib import pyplot as plt
import numpy as np
import pywt
 

wavename='haar'

def guass_noise(image, mean=0, var=0.001):
    ''' 
        添加高斯噪声
        mean : 均值 
        var : 方差
    '''
    image = np.array(image/255, dtype=float)
    noise = np.random.normal(mean, var ** 0.5, image.shape)
    out = image + noise
    if out.min() < 0:
        low_clip = -1.
    else:
        low_clip = 0.
    out = np.clip(out, low_clip, 1.0)
    out = np.uint8(out*255)
    #cv.imshow("gasuss", out)
    return out
 

 
def wiener_filter(Y, HH):
    #r padding半径
    row, col = np.shape(Y)
    noise_std = (np.median(np.abs(HH)) / 0.6745)
    noise_var = noise_std ** 2
    var = 1 / (row * col) * np.sum(Y * Y) - noise_var
    X = Y * var / (var + noise_var)
    return X
 
def wiener_dwt(img, index = 1):
    #index 为进行几层分解与重构
    img = np.array(img, dtype = float)
    coeffs = pywt.dwt2(img, wavename)
    LL, (LH, HL, HH) = coeffs
 
    #LL为低频信号 LH为水平高频 HL为垂直高频  HH为对角线高频信号
 
    #维纳滤波
    LH = wiener_filter(LH, HH)
    HL = wiener_filter(HL, HH)
    HH = wiener_filter(HH, HH)
 
    #重构
    if index > 1:
        LL = wiener_dwt(LL, index - 1)

    
    time=5
    plt.figure()
    plt.tight_layout()
    plt.subplot(2, 2, 1)
    plt.imshow(LL, cmap='gray')
    plt.title('The ' + str(time - index + 1) + 'th dwt--' + 'LL')
    plt.subplot(2, 2, 2)
    plt.imshow(LH, cmap='gray')
    plt.title('The ' + str(time - index + 1) + 'th dwt--' + 'LH')
    plt.subplot(2, 2, 3)
    plt.tight_layout()
    plt.imshow(HL, cmap='gray')
    plt.title('The ' + str(time - index + 1) + 'th dwt---' + 'HL')
    plt.subplot(2, 2, 4)
    plt.imshow(HH, cmap='gray')
    plt.title('The ' + str(time - index + 1) + 'th dwt---' + 'HH')
    plt.tight_layout()
    # plt.show()
    pic_ans = pywt.idwt2((LL, (LH, HL, HH)), wavename)
    plt.savefig('%sth_dwt.png'%str(time - index + 1),dpi=500)
    
    return pic_ans
 
 
if __name__ == "__main__":

    #读图

    filename='lena.tif'
    img= cv2.imread(filename, cv2.IMREAD_GRAYSCALE)
    img_noisy= guass_noise(img,var=0.01)   #加高斯噪声



    f_process = wiener_dwt(img_noisy, 5)
    f_process = np.where(f_process <= 0, 0, f_process)
    f_process = np.where(f_process > 255, 255, f_process)
    f_process = np.uint8(f_process)

    plt.figure()
    plt.subplot(1, 3, 1)
    plt.tight_layout()
    plt.imshow(img, cmap = 'gray')
    plt.title('original image')
    plt.subplot(1, 3, 2)
    plt.imshow(img_noisy,cmap = 'gray')
    plt.title('image+gaussian noise') 
    plt.tight_layout()
    plt.subplot(1, 3, 3)
    plt.imshow(f_process, cmap='gray')
    plt.title('wiener_filter image')
    plt.tight_layout()
    plt.savefig('total.png',dpi=500)
  



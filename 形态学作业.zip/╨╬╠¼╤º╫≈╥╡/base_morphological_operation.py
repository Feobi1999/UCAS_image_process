import numpy as np
import cv2


"二值化, 腐蚀，膨胀，开，击中击不中，细化 "

def binaryzation(img,threshold=127):
    # print(img)
    img1=img.copy()
    img[img1 <= threshold] = 255
    img[img1 > threshold] = 0

    return img.astype(np.uint8)



def erode(a, b):
    img=np.array(a)
    sum_b=np.sum(b)
    # print(sum_b)
    conv=cv2.filter2D(img, -1, b, borderType=cv2.BORDER_CONSTANT)
    conv2 = np.where(conv == sum_b,1, 0)
    # print(sum(conv==9))
    return conv2.astype(np.uint8)



def dilate(a, b):
    # 结构元进行卷积，需要旋转180°
    b_reflect = np.rot90(b, 2)
    dst = cv2.filter2D(a, -1, b_reflect, borderType=cv2.BORDER_CONSTANT)
    dst = np.where(dst > 0, 1, 0)
    return dst.astype(np.uint8)

def open_trans(a,b):
    dst=dilate(erode(a,b),b)
    return dst.astype(np.uint8)


def hit_miss(a, b):
    b1 = np.where(b == 1, 1, 0).astype(np.uint8)
    b2 = np.where(b == 0, 1, 0).astype(np.uint8)
    # 填充一下以解决边界
    padding = cv2.copyMakeBorder(a, 1, 1, 1, 1, cv2.BORDER_CONSTANT, value=0)

    eroded = cv2.erode(padding, b1)

    a_not = 1 - padding
    eroded2 = cv2.erode(a_not, b2)

    # 去除填充边界
    dst = cv2.bitwise_and(eroded, eroded2)[1:-1, 1:-1]
    return dst.astype(np.uint8)


# def thin(f, b):
#     hit_miss_res = hit_miss(f, b)

#     # 记录每个像素是不是连通的
#     kernel = np.array([[1, 1, 1], [1, 0, 1], [1, 1, 1]])
#     neighbor_num = cv2.filter2D(f, -1, kernel, borderType=cv2.BORDER_CONSTANT)
#     connected = np.where(neighbor_num == 0, 0, 1)

#     # 击中击不中变换中连通的像素才需要被删除
#     deleted = cv2.bitwise_and(hit_miss_res, connected.astype(np.uint8))

#     return cv2.subtract(f, deleted)
def thin(f, b):
    hit_miss_res = hit_miss(f, b)
    res = cv2.subtract(f, hit_miss_res)
    return res
    

import numpy as np
from matplotlib import pyplot as plt
import cv2
from base_morphological_operation import *

def distance_transform(img):
    height, width = img.shape
    A = np.where(img == 0, np.Inf, 1)
    # 
    padding = cv2.copyMakeBorder(A, 1, 1, 1, 1, cv2.BORDER_CONSTANT, value=np.inf)
    for i in range(1, height): 
        for j in range(1, width - 1):  
            temp1 = min(padding[i][j-1] + 3, padding[i][j])
            temp2 = min(padding[i-1][j-1] + 4, temp1)
            temp3 = min(padding[i-1][j] + 3, temp2)
            padding[i][j] = min(padding[i-1][j+1]+4, temp3)
    for i in range(height - 1,-1, -1): 
        for j in range(width - 1, 0, -1): 
            temp1 = min(padding[i][j+1] + 3, padding[i][j])
            temp2 = min(padding[i+1][j+1] + 4, temp1)
            temp3 = min(padding[i+1][j] + 3, temp2)
            padding[i][j] = min(padding[i+1][j+1]+4, temp3)
    D = np.round(padding[1:height+1, 1:width+1]/3)
    return D

def edge_extract(a):
    b = np.ones((3, 3), np.uint8)
    return cv2.subtract(a, cv2.erode(a, b))

def get_local_max_img(img):
    dst = np.zeros_like(img)
    print(dst.shape)
    height, width = img.shape
    padding = img.copy()
    padding = cv2.copyMakeBorder(
        padding, 3, 3, 3, 3, borderType=cv2.BORDER_CONSTANT, value=np.inf)
    print(padding.shape)
    # 每个像素的7*7邻域极大
    for i in range(height):
        for j in range(width):
            neighbor = padding[i:i+7, j:j+7]
            if img[i][j] == np.max(neighbor):
                dst[i][j] = 1
    return dst.astype(np.uint8)
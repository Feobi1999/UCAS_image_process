import cv2
import numpy as np
from matplotlib import pyplot as plt
from base_morphological_operation import *
from distance_skeleton_extract import *
import copy
import math


#形态学骨架提取
def morphological_skeleton_subsets(X, B):
    S = []
    X_n = X
    while np.count_nonzero(X_n) > 0:
        X_n = cv2.erode(X_n, B)   
        temp_img = copy.deepcopy(X_n)
        S_n=temp_img-cv2.morphologyEx(X_n, cv2.MORPH_OPEN, B, iterations=1)
        S.append(S_n)

    return S


#细化
def morphological_thin(binary):
    b = []
    b.append(np.array([[0, 0, 0], [-1, 1, -1], [1, 1, 1]]))
    b.append(np.array([[-1, 0, 0], [1, 1, 0], [1, 1, -1]]))
    b.append(np.array([[1, -1, 0], [1, 1, 0], [1, -1, 0]]))
    b.append(np.array([[1, 1, -1], [1, 1, 0], [-1, 0, 0]]))
    b.append(np.array([[1, 1, 1], [-1, 1, -1], [0, 0, 0]]))
    b.append(np.array([[-1, 1, 1], [0, 1, 1], [0, 0, -1]]))
    b.append(np.array([[0, -1, 1], [0, 1, 1], [0, -1, 1]]))
    b.append(np.array([[0, 0, -1], [0, 1, 1], [-1, 1, 1]]))

    dst = binary.copy()
    # 迭代次数
    thin_num = 0
    # 利用b中的核不断进行细化直到细化前后无变化
    while True:
        isConverged = False
        for bi in b:
            thinned = thin(dst, bi)
            if (thinned == dst).all():
                isConverged = True
                break
            else:
                dst = thinned
                thin_num += 1
        if isConverged:
            break
    return dst.astype(np.uint8)

# 距离变换骨架提取
def distance_skeleton_extract(img):
    edge_img = edge_extract(img)   #提取边界
    dis_img = distance_transform(edge_img)   #边界图像距离变换
    distance_skeleton = get_local_max_img(dis_img) #得到局部极大值

    return cv2.bitwise_and(distance_skeleton,img)



#裁剪
def cut(a):
    b = []
    b.append(np.array([[0, 0, 0], [1, 1, 0], [0, 0, 0]]))
    b.append(np.rot90(np.array([[0, 0, 0], [1, 1, 0], [0, 0, 0]]), 1))
    b.append(np.rot90(np.array([[0, 0, 0], [1, 1, 0], [0, 0, 0]]), 2))
    b.append(np.rot90(np.array([[0, 0, 0], [1, 1, 0], [0, 0, 0]]), 3))
    b.append(np.array([[1, 0, 0], [0, 1, 0], [0, 0, 0]]))
    b.append(np.rot90(np.array([[1, 0, 0], [0, 1, 0], [0, 0, 0]]), 1))
    b.append(np.rot90(np.array([[1, 0, 0], [0, 1, 0], [0, 0, 0]]), 2))
    b.append(np.rot90(np.array([[1, 0, 0], [0, 1, 0], [0, 0, 0]]), 3))


    x1=morphological_thin(a)

    x2 = np.zeros_like(x1)
    for bi in b:
        x2_component = hit_miss(x1.copy(), bi)
        x2 = np.bitwise_or(x2, x2_component)

    H = np.array([[1, 1, 1], [1, 1, 1], [1, 1, 1]])
    # 裁剪中进行腐蚀的次数
    DILATE_NUM = 3
    dilated = x2.copy()
    for i in range(DILATE_NUM):
        eroded = dilate(dilated, H)

    x3 = np.bitwise_and(dilated, a)

    return np.bitwise_or(x1, x3)








if __name__ == "__main__":
    
    #结构算子
    B = cv2.getStructuringElement(cv2.MORPH_CROSS, (3, 3))

    X=cv2.imread('zhiwen.jpg',cv2.IMREAD_GRAYSCALE)
    


    #二值化
    X=binaryzation(X)
    plt.imsave('binary.png',X,cmap='gray')
    
    # 形态学求骨架
    S = morphological_skeleton_subsets(X, B)
    # temp=S[6]
   
    #距离变换骨架
    distance_skeleton = distance_skeleton_extract(X)
    


    "show the results"

    fig = plt.figure(figsize=(25, 15))
    plt.gray()
    fig.add_subplot(3, (math.ceil(len(S)/3)), 1)
    plt.imshow(X,cmap='gray')
    plt.title("Original Image")
    plt.axis('off')
    print(len(S))
    morphological_skeleton=np.zeros_like(X)
    for i, s in enumerate(S):
        fig.add_subplot(3, (math.ceil(len(S)/3)), i + 2)
        plt.imshow(s)
        plt.title("$S_{" + str(i) + "}$")
        plt.axis('off')
        morphological_skeleton=cv2.bitwise_or(morphological_skeleton,s)
    plt.savefig('subset.png')
    plt.show()

    fig = plt.figure()
    plt.subplot(1, 2, 1)
    plt.title("Original Image")
    plt.imshow(X)
    plt.subplot(1, 2, 2)
    plt.title('morphological skeleton img')
    plt.imshow(morphological_skeleton)
    plt.margins(10, 10)
    plt.show()

    morphological_skeleton_cut = cut(morphological_skeleton)
    distance_skeleton_cut=cut(distance_skeleton)
    
    fig = plt.figure()
    plt.subplot(1, 2, 1)
    plt.title("Original Image")
    plt.imshow(X)
    plt.subplot(1, 2,2)
    plt.title('dist_trans skeleton img')
    plt.imshow(distance_skeleton)
    plt.show()

    fig = plt.figure()
    plt.subplot(1, 2, 1)
    plt.title('morphological skeleton')
    plt.imshow(morphological_skeleton)
    plt.subplot(1, 2,2)
    plt.title('distance transform skeleton')
    plt.imshow(distance_skeleton,cmap='gray')
    plt.margins(10, 10)
    # plt.subplots_adjust(top=1, bottom=0, right=0.93, left=0, hspace=0, wspace=0)
    plt.show()


    fig = plt.figure()


    plt.subplot(1, 3, 1)
    plt.title('dis_skeleton_img')
    plt.tight_layout()
    plt.imshow(distance_skeleton)
    plt.subplot(1, 3,2)
    plt.title('dis_cut_img')
    plt.tight_layout()
    plt.imshow(distance_skeleton_cut)
    # plt.savefig("dis_cut.png",dpi=500)
    plt.subplot(1, 3,3)
    dis2=distance_skeleton-distance_skeleton_cut
    plt.title('cut_difference')
    plt.imshow(dis2)
    plt.show()

    fig = plt.figure()
    plt.subplot(1, 3, 1)
    plt.title('mor_skeleton_img')
    plt.tight_layout()
    plt.imshow(morphological_skeleton)
    plt.subplot(1, 3,2)
    plt.title('mor_cut_img')
    plt.tight_layout()
    plt.imshow(morphological_skeleton_cut)
    # plt.savefig("mor_cut.png",dpi=500)
    plt.subplot(1, 3,3)
    dis=morphological_skeleton_cut-morphological_skeleton
    plt.imshow(dis)
    plt.title('cut_differnce')
    plt.tight_layout()
    plt.show()





